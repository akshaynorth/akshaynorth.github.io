# Anthony Aneke's Code Institute Milestone Project 1

## Introduction
The project milestone 1 is to employ user-centric front end development to create
a website. The milestone gives two options:

1. Select a project idea from a suggested list of projects
2. Create a website outside for a purpose outside of the suggested list of ideas

I have selected to develop a website not in the selected list of ideas.

## Purpose
This website is for intellectual property law support.

## Code Template Credits
For the development of this milestone project 1 a website template was employed. 
The template contains a set of HTML, CSS (Bootstrap4), JavaScript files that can be
altered as needed. The code was downloaded from the following website::

    https://themewagon.com/

The site contains a collection of  free and paid templates. For this assignent, I
choosed the *Legal Care* webiste template. The chosen website template can be found
at::

    https://themewagon.com/themes/free-bootstrap-4-html5-responsive-law-firm-website-template-legalcare/
<<<<<<< HEAD

=======
>>>>>>> 0c89d16267ea47df33c523420ce9b17b9b0698c7
